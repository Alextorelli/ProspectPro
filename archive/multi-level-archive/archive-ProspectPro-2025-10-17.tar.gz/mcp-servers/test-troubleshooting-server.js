#!/usr/bin/env node

/**
 * Test script for ProspectPro Troubleshooting MCP Server
 * Validates all troubleshooting tools and functionality
 */

const { execSync } = require("child_process");
const fs = require("fs");

const COLORS = {
  GREEN: "\x1b[32m",
  RED: "\x1b[31m",
  YELLOW: "\x1b[33m",
  BLUE: "\x1b[34m",
  RESET: "\x1b[0m",
};

const log = (color, message) =>
  console.log(`${color}${message}${COLORS.RESET}`);

async function testTroubleshootingServer() {
  log(COLORS.BLUE, "🔧 Testing ProspectPro Troubleshooting MCP Server...\n");

  const tests = [
    {
      name: "Server File Exists",
      test: () => fs.existsSync("./supabase-troubleshooting-server.js"),
      fix: "Create supabase-troubleshooting-server.js in /mcp-servers/",
    },
    {
      name: "Dependencies Available",
      test: () => {
        try {
          const pkg = JSON.parse(fs.readFileSync("./package.json", "utf8"));
          return (
            pkg.dependencies["@modelcontextprotocol/sdk"] &&
            pkg.dependencies["@supabase/supabase-js"]
          );
        } catch {
          return false;
        }
      },
      fix: "Run: npm install @modelcontextprotocol/sdk @supabase/supabase-js",
    },
    {
      name: "Server Syntax Valid",
      test: () => {
        try {
          require("./supabase-troubleshooting-server.js");
          return true;
        } catch (error) {
          log(COLORS.RED, `Syntax error: ${error.message}`);
          return false;
        }
      },
      fix: "Check JavaScript syntax in troubleshooting server",
    },
    {
      name: "MCP Config Exists",
      test: () => fs.existsSync("../.vscode/mcp-config.json"),
      fix: "Create .vscode/mcp-config.json with troubleshooting server config",
    },
    {
      name: "Package Scripts Updated",
      test: () => {
        const pkg = JSON.parse(fs.readFileSync("./package.json", "utf8"));
        return (
          pkg.scripts["start:troubleshooting"] &&
          pkg.scripts["start:all"].includes("troubleshooting")
        );
      },
      fix: "Update package.json scripts to include troubleshooting server",
    },
  ];

  let passed = 0;
  let failed = 0;

  for (const test of tests) {
    try {
      if (test.test()) {
        log(COLORS.GREEN, `✅ ${test.name}`);
        passed++;
      } else {
        log(COLORS.RED, `❌ ${test.name}`);
        log(COLORS.YELLOW, `   Fix: ${test.fix}`);
        failed++;
      }
    } catch (error) {
      log(COLORS.RED, `❌ ${test.name} - Error: ${error.message}`);
      log(COLORS.YELLOW, `   Fix: ${test.fix}`);
      failed++;
    }
  }

  log(COLORS.BLUE, `\n📊 Test Results: ${passed} passed, ${failed} failed`);

  if (failed === 0) {
    log(COLORS.GREEN, "🎉 All troubleshooting server tests passed!");
    log(COLORS.BLUE, "\n🚀 Quick Start Commands:");
    log(
      COLORS.RESET,
      "npm run start:troubleshooting  # Start troubleshooting server"
    );
    log(COLORS.RESET, "npm run start:all             # Start all MCP servers");
    log(COLORS.RESET, "npm run debug:anon-key        # Debug anon key issues");
    log(
      COLORS.RESET,
      "npm run debug:edge-functions  # Debug Edge Function issues"
    );
    log(COLORS.RESET, "npm run debug:database        # Debug database issues");

    log(COLORS.BLUE, "\n🔧 Available MCP Tools:");
    log(
      COLORS.RESET,
      "• test_edge_function          - Test Supabase Edge Function connectivity"
    );
    log(
      COLORS.RESET,
      "• validate_database_permissions - Check RLS policies and permissions"
    );
    log(
      COLORS.RESET,
      "• check_vercel_deployment     - Validate Vercel deployment status"
    );
    log(
      COLORS.RESET,
      "• diagnose_anon_key_mismatch  - Compare frontend vs Supabase anon keys"
    );
    log(
      COLORS.RESET,
      "• run_rls_diagnostics         - Generate RLS diagnostic queries"
    );
    log(
      COLORS.RESET,
      "• generate_debugging_commands - Create custom debugging scripts"
    );

    return true;
  } else {
    log(COLORS.RED, "❌ Some tests failed. Please fix the issues above.");
    return false;
  }
}

// Run tests if called directly
if (require.main === module) {
  testTroubleshootingServer()
    .then((success) => process.exit(success ? 0 : 1))
    .catch((error) => {
      log(COLORS.RED, `Fatal error: ${error.message}`);
      process.exit(1);
    });
}

module.exports = { testTroubleshootingServer };
