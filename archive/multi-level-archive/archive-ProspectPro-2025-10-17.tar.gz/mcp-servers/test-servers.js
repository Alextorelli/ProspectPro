#!/usr/bin/env node

/**
 * Test script for ProspectPro Consolidated MCP Servers
 * Tests both production and development servers
 */

import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class MCPServerTester {
  constructor() {
    this.results = {
      timestamp: new Date().toISOString(),
      servers: {},
      configuration: {
        vscode_config: false,
        package_json: false,
        errors: [],
      },
      dependencies: {
        package_json: false,
        mcp_sdk: false,
        supabase: false,
        errors: [],
      },
      overall_status: "unknown",
    };
  }

  async testServer(serverName, serverFile) {
    console.log(`\n🧪 Testing ${serverName}...`);

    const serverTest = {
      name: serverName,
      file: serverFile,
      loadable: false,
      class_instantiable: false,
      server_methods: [],
      errors: [],
    };

    try {
      // Test if server file exists
      const serverPath = path.join(__dirname, serverFile);
      if (!fs.existsSync(serverPath)) {
        throw new Error(`Server file ${serverFile} not found`);
      }

      // Test if server is loadable
      const serverModule = await import(serverPath);
      const ServerClass = serverModule.default;
      serverTest.loadable = true;
      console.log(`  ✅ ${serverName} is loadable`);

      // Test if class is instantiable
      const server = new ServerClass();
      serverTest.class_instantiable = true;
      console.log(`  ✅ ${serverName} class instantiable`);

      // Test available methods
      const methods = Object.getOwnPropertyNames(
        Object.getPrototypeOf(server)
      ).filter(
        (name) => name !== "constructor" && typeof server[name] === "function"
      );

      serverTest.server_methods = methods;
      console.log(`  ✅ ${serverName} has ${methods.length} methods`);

      // Test server can be configured
      if (server.server) {
        console.log(`  ✅ ${serverName} MCP server initialized`);
      }
    } catch (error) {
      serverTest.errors.push(error.message);
      console.log(`  ❌ ${serverName} error: ${error.message}`);
    }

    return serverTest;
  }

  async testConfiguration() {
    console.log(`\n🔧 Testing configuration...`);

    // Test package.json
    try {
      const packagePath = path.join(__dirname, "package.json");
      if (fs.existsSync(packagePath)) {
        const packageData = JSON.parse(fs.readFileSync(packagePath, "utf8"));
        this.results.configuration.package_json = true;
        console.log(`  ✅ package.json exists and is valid`);
      }
    } catch (error) {
      this.results.configuration.errors.push(
        `package.json error: ${error.message}`
      );
      console.log(`  ❌ package.json error: ${error.message}`);
    }

    // Test VS Code settings (JSONC format) - simplified validation
    try {
      const vscodeSettings = path.join(__dirname, "../.vscode/settings.json");
      if (fs.existsSync(vscodeSettings)) {
        const content = fs.readFileSync(vscodeSettings, "utf8");
        // Check for key indicators rather than full JSON parsing
        const hasMcpEnable = content.includes('"mcp.enable": true');
        const hasMcpServers = content.includes('"mcp.servers"');
        const hasProductionServer = content.includes(
          '"prospectpro-production"'
        );
        const hasDevelopmentServer = content.includes(
          '"prospectpro-development"'
        );

        this.results.configuration.vscode_config =
          hasMcpEnable &&
          hasMcpServers &&
          hasProductionServer &&
          hasDevelopmentServer;
        console.log(
          `  ✅ VS Code settings configured with MCP: ${this.results.configuration.vscode_config}`
        );
        console.log(`    - MCP enabled: ${hasMcpEnable}`);
        console.log(`    - Production server: ${hasProductionServer}`);
        console.log(`    - Development server: ${hasDevelopmentServer}`);
      }
    } catch (error) {
      this.results.configuration.errors.push(
        `VS Code config error: ${error.message}`
      );
      console.log(`  ❌ VS Code config error: ${error.message}`);
    }
  }

  async testDependencies() {
    console.log(`\n📦 Testing dependencies...`);

    try {
      const packagePath = path.join(__dirname, "package.json");
      const packageData = JSON.parse(fs.readFileSync(packagePath, "utf8"));

      this.results.dependencies.package_json = true;

      // Check MCP SDK
      if (
        packageData.dependencies &&
        packageData.dependencies["@modelcontextprotocol/sdk"]
      ) {
        this.results.dependencies.mcp_sdk = true;
        console.log(`  ✅ MCP SDK dependency found`);
      }

      // Check Supabase
      if (
        packageData.dependencies &&
        packageData.dependencies["@supabase/supabase-js"]
      ) {
        this.results.dependencies.supabase = true;
        console.log(`  ✅ Supabase dependency found`);
      }

      // Try to import MCP SDK
      await import("@modelcontextprotocol/sdk/server/index.js");
      console.log(`  ✅ MCP SDK can be loaded`);

      // Try to import Supabase
      await import("@supabase/supabase-js");
      console.log(`  ✅ Supabase can be loaded`);
    } catch (error) {
      this.results.dependencies.errors.push(error.message);
      console.log(`  ❌ Dependencies error: ${error.message}`);
    }
  }

  async run() {
    console.log(`🚀 ProspectPro Consolidated MCP Server Test Suite`);
    console.log(`📅 ${this.results.timestamp}\n`);

    // Test consolidated servers
    const servers = [
      { name: "production-server", file: "./production-server.js" },
      { name: "development-server", file: "./development-server.js" },
    ];

    for (const server of servers) {
      this.results.servers[server.name] = await this.testServer(
        server.name,
        server.file
      );
    }

    await this.testConfiguration();
    await this.testDependencies();

    // Determine overall status
    const serverErrors = Object.values(this.results.servers).reduce(
      (acc, server) => acc + server.errors.length,
      0
    );
    const configErrors = this.results.configuration.errors.length;
    const depErrors = this.results.dependencies.errors.length;

    if (serverErrors === 0 && configErrors === 0 && depErrors === 0) {
      this.results.overall_status = "healthy";
    } else if (serverErrors === 0) {
      this.results.overall_status = "minor_issues";
    } else {
      this.results.overall_status = "needs_attention";
    }

    // Save results
    const resultsPath = path.join(__dirname, "test-results.json");
    fs.writeFileSync(resultsPath, JSON.stringify(this.results, null, 2));

    // Print summary
    console.log(`\n📊 Test Summary:`);
    console.log(`   Status: ${this.results.overall_status}`);
    console.log(
      `   Servers tested: ${Object.keys(this.results.servers).length}`
    );
    console.log(`   Server errors: ${serverErrors}`);
    console.log(`   Config errors: ${configErrors}`);
    console.log(`   Dependency errors: ${depErrors}`);
    console.log(`\n💾 Results saved to test-results.json`);

    return this.results.overall_status === "healthy";
  }
}

// Run if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const tester = new MCPServerTester();
  tester
    .run()
    .then((success) => {
      process.exit(success ? 0 : 1);
    })
    .catch((error) => {
      console.error("❌ Test suite failed:", error);
      process.exit(1);
    });
}

export default MCPServerTester;
