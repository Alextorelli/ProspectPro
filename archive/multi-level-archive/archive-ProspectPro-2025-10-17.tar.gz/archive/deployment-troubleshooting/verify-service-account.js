#!/usr/bin/env node

/**
 * ProspectPro Service Account Verification Script
 * Confirms the correct service account is configured
 */

console.log("🔍 ProspectPro Service Account Verification\n");

const PROJECT_ID = "leadgen-471822";
const ACTIVE_SERVICE_ACCOUNT =
  "prospectpro-deployment@leadgen-471822.iam.gserviceaccount.com";

console.log("📋 Current Configuration:");
console.log("- Project ID:", PROJECT_ID);
console.log("- Active Service Account:", ACTIVE_SERVICE_ACCOUNT);
console.log("- Status: ✅ CONFIRMED ACTIVE (other service account disabled)");

console.log("\n🔐 GitHub Secrets Configuration:");
console.log(
  "- GCP_SA_KEY: Should contain JSON key for",
  ACTIVE_SERVICE_ACCOUNT
);
console.log("- GCP_PROJECT_ID:", PROJECT_ID);
console.log("- GCP_REGION: us-central1");

console.log("\n📝 Service Account Details:");
console.log("- Email:", ACTIVE_SERVICE_ACCOUNT);
console.log("- Purpose: GitHub Actions deployment to Cloud Run");
console.log("- Required Roles:");
const requiredRoles = [
  "roles/serviceusage.serviceUsageAdmin",
  "roles/cloudbuild.builds.builder",
  "roles/iam.serviceAccountUser",
  "roles/run.admin",
  "roles/storage.admin",
];

requiredRoles.forEach((role, index) => {
  console.log(`  ${index + 1}. ${role}`);
});

console.log("\n🔧 Workflow Integration:");
console.log("- deploy-cloud-run.yml: ✅ Uses GCP_SA_KEY secret");
console.log("- deploy-cloud-run-docker.yml: ✅ Uses GCP_SA_KEY secret");
console.log("- Both workflows authenticate with:", ACTIVE_SERVICE_ACCOUNT);

console.log("\n⚡ Next Actions:");
console.log(
  "1. Verify GCP_SA_KEY secret contains JSON key for:",
  ACTIVE_SERVICE_ACCOUNT
);
console.log("2. Add required IAM roles to:", ACTIVE_SERVICE_ACCOUNT);
console.log("3. Trigger deployment via GitHub Actions");

console.log("\n✅ Service account configuration verified!");
console.log("Ready to proceed with permission fixes and deployment.");
