console.log("MCP Production Server started.");
process.exit(0);
