console.log("MCP Troubleshooting Server started.");
process.exit(0);
