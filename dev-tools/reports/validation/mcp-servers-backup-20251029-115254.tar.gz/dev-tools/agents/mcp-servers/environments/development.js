console.log("MCP Development Server started.");
process.exit(0);
